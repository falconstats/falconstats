<html>
<body>
	<form name="upload" action="upload.php" method="post" accept-charset="utf-8">
		<input type="hidden" name="user_name" value="../kolbe">
		<input type="hidden" name="user_pw" value="moep">
		<input type="hidden" value="797f7d2bc52d97daed8032e1d84a3d858c81369e" name="hash">
		<textarea name="logbook" cols="80" rows="40"></textarea>
		<p><input type="submit" value="Continue &rarr;"></p>
	</form>
</body>
</html>