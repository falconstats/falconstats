<?php
if($id=="licence") {
	echo("<a href=\"http://falconstats.23-media.com\" alt=\"http://falconstats.23-media.com\">Copyrightunder Creative Commons. Check back our Website http://falconstats.23-media.com</a>");
	die();
}
?>