<?php
 /* German language file */
 
Pilot Name:Piloten Name
Commissioned Date : Dabei seit
Number of Flight Hours : Flugstunden
Rank : Rang
Callsign : Rufzeichen
Medals : Auszeichnungen
CAMPAIGN STATS : Kampagnen Statistiken
Total Missions Flown : Geflogene Missionen
Air to Ground : Bodenziele
Consecutive Missions : Missionen ohne Abschuss
Friendlies Killed : Zerst�rte Freundeinheiten
Games Lost : Verloren
Games Tied : Unentschieden
Games Won : Gewonnen
Human Kills : Menschl. Piloten abgeschossen
Number of Times Killed by Human : Von menschl. Piloten abgeschossen
Killed by Self : Unf�lle
Number of Kills : Gestorben
Total Adjusted Score : Punkte
Total Score : Kampagnen Punkte
Static Kills : Zerst�rte Bodenziele
Naval Kills : Zerst�rte Schiffe
Miss Since Last Friendly Kill : Keine Ahnung
DOGFIGHT STATS : Dogfight Statistiken
Matches Won : Gewonnene Spiele
Matches Lost : Verlorene Spiele
Matches Won vs Humans : Gegen Menschen gewonnene Spiele
Matches Lost vS Humans : Gegen Menschen verlorene Spiele
Total Kills : Abgeschossene Flugzeuge
Total Times Killed : Gestorben
Total Human Kills : Menschl. Piloten abgeschossen
Times Killed by Humans : Von menschl. Piloten abgeschossen

?>