<?php

/* config file */

$lang="de"; // specifies which language is used. (Currently german and english only)
$template="49th"; // specifies the template that is Used
$checksum="797f7d2bc52d97daed8032e1d84a3d858c81369e"; // Internal Checksum


?>